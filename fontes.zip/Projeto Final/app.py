#
# Trabalho Final
# 
# Aluno      : Igor Leal Antunes (11211416) e Fernando Souza (11218354)
# Disciplina : Analise e Projeto de Algoritmos - 2016.2
# Professor  : GILBERTO FARIAS DE SOUSA FILHO 
#
#
# uso : 
#       utilizando pipe de arquivo:
#           > python3 app.py < nome_do_arquivo.txt
#           
#           
from City import City
from TSP import TSP

import random
import time
import itertools
import urllib
import csv
import functools
import pprint 
	
def main():
		
	cities = []

	while True:
		try:
			line = input().strip()

			if line == "NODE_COORD_SECTION":
			   
				while True:
					try:
						
						line = input().split()
						city = City(line[0], line[1], line[2])
						cities.append(city)
					except Exception as e:
						#print ("1 " + str(e) + " city :" + str(city.id))
						break;

		except Exception as e:
			#print ("2 " + str(e) + " city :" + str(city.id))
			break;
	
	tsp = TSP()
	M = tsp.get_distance_matrix(cities)
	
	tour = tsp.nn_tsp(cities, M)
	
	#new_tour = tsp.swap_2opt(tour[0:5], M)
	#new_tour = tsp.swap_3opt(tour, M)
	
	#print("2opt\n\n")
	#new_tour = tsp.swap_2opt_2(tour, M)
	#print("\n\n3opt\n\n")
	#new_tour = tsp.swap_3opt_2(new_tour, M)
	#new_tour = tsp.swap_2opt(tour, M, 10**6);

	new_tour = tsp.VND(tour, M)

	custo_original = tsp.get_cost(tour, M)
	custo_final = tsp.get_cost(new_tour, M)
	melhora = (1 - (custo_final / custo_original)) * 100.0

	print("\nCusto Original (com vizinho mais proximo): " + str(custo_original))
	#tsp.print_tour_simple(tour)
	print("Custo Otimizado pelo VND: " + str(custo_final)) 
	print("Melhora : " + str(melhora) + " %")

	#tsp.print_tour_simple(new_tour)

	#tsp.plot_cities(tour)
	#tsp.plot_cities(new_tour)

main()



